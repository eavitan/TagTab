// background.js (MV3 service worker)
// Storage schema:
//  storage.local: {
//    tags: {
//      [tagName]: [{ url, title, favIconUrl, savedAt }...]
//    }
//  }

const getStore = () => new Promise(resolve => {
  chrome.storage.local.get({ tags: {} }, resolve);
});

const setStore = (tags) => new Promise(resolve => {
  chrome.storage.local.set({ tags }, resolve);
});

async function ensureTag(tags, tag) {
  if (!tags[tag]) tags[tag] = [];
}

function nowISO() {
  return new Date().toISOString();
}

async function saveTabsToTag(tag, scope = "currentWindow") {
  const { tags } = await getStore();
  await ensureTag(tags, tag);

  const query = scope === "allWindows" ? { pinned: false } : { currentWindow: true, pinned: false };
  const tabs = await chrome.tabs.query(query);
  // Filter usable tabs (http/https/chrome-extension/etc.) but skip chrome:// and about:blank
  const closable = tabs.filter(t => t.url && !t.url.startsWith("chrome://") && !t.url.startsWith("edge://") && !t.url.startsWith("about:blank"));

  // Save
  for (const t of closable) {
    tags[tag].push({
      url: t.url,
      title: t.title || t.url,
      favIconUrl: t.favIconUrl || "",
      savedAt: nowISO()
    });
  }
  await setStore(tags);

  // Create a new tab first to avoid window closing
  await chrome.tabs.create({ url: "chrome://newtab" });

  // Close the old tabs
  const toClose = closable.map(t => t.id).filter(Boolean);
  if (toClose.length) {
    await chrome.tabs.remove(toClose);
  }
  return { saved: closable.length };
}

async function getTags() {
  const { tags } = await getStore();
  return Object.keys(tags).sort();
}

async function getTagData(tag) {
  const { tags } = await getStore();
  return tags[tag] || [];
}

async function deleteItem(tag, index) {
  const { tags } = await getStore();
  if (!tags[tag]) return;
  tags[tag].splice(index, 1);
  await setStore(tags);
}

async function deleteTag(tag) {
  const { tags } = await getStore();
  delete tags[tag];
  await setStore(tags);
}

async function restoreItem(item) {
  await chrome.tabs.create({ url: item.url });
}

async function restoreAll(tag) {
  const list = await getTagData(tag);
  for (const item of list) {
    await restoreItem(item);
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      if (msg.type === "getTags") {
        const list = await getTags();
        sendResponse({ ok: true, tags: list });
      } else if (msg.type === "saveAndClose") {
        const { tag, scope } = msg;
        const res = await saveTabsToTag(tag, scope);
        sendResponse({ ok: true, ...res });
      } else if (msg.type === "getTagData") {
        const list = await getTagData(msg.tag);
        sendResponse({ ok: true, items: list });
      } else if (msg.type === "deleteItem") {
        await deleteItem(msg.tag, msg.index);
        sendResponse({ ok: true });
      } else if (msg.type === "deleteTag") {
        await deleteTag(msg.tag);
        sendResponse({ ok: true });
      } else if (msg.type === "restoreItem") {
        await restoreItem(msg.item);
        sendResponse({ ok: true });
      } else if (msg.type === "restoreAll") {
        await restoreAll(msg.tag);
        sendResponse({ ok: true });
      } else {
        sendResponse({ ok: false, error: "Unknown message type" });
      }
    } catch (e) {
      console.error(e);
      sendResponse({ ok: false, error: String(e) });
    }
  })();
  return true; // keep channel open for async
});
