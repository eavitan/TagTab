const $ = s => document.querySelector(s);
const tabbar = $("#tabbar");
const content = $("#content");

function fmtDate(iso) {
  try {
    const d = new Date(iso);
    return d.toLocaleString();
  } catch { return ""; }
}

async function fetchTags() {
  const res = await chrome.runtime.sendMessage({ type: "getTags" });
  return res.ok ? res.tags : [];
}

async function fetchItems(tag) {
  const res = await chrome.runtime.sendMessage({ type: "getTagData", tag });
  return res.ok ? res.items : [];
}

async function render(tag) {
  tabbar.innerHTML = "";
  const tags = await fetchTags();
  if (!tags.length) {
    content.innerHTML = '<div class="empty">No saved pages yet.</div>';
    return;
  }
  for (const t of tags) {
    const btn = document.createElement("div");
    btn.className = "tab" + (t === tag ? " active" : "");
    btn.textContent = t;
    btn.addEventListener("click", () => render(t));
    tabbar.appendChild(btn);
  }
  if (!tag) tag = tags[0];

  const items = await fetchItems(tag);
  content.innerHTML = "";

  const controls = document.createElement("div");
  controls.className = "controls";
  const restoreAllBtn = document.createElement("button");
  restoreAllBtn.textContent = "Restore all";
  restoreAllBtn.onclick = async () => chrome.runtime.sendMessage({ type: "restoreAll", tag });
  const deleteTagBtn = document.createElement("button");
  deleteTagBtn.textContent = "Delete tag";
  deleteTagBtn.onclick = async () => {
    if (!confirm(`Delete all items in “${tag}”?`)) return;
    await chrome.runtime.sendMessage({ type: "deleteTag", tag });
    render(null);
  };
  controls.append(restoreAllBtn, deleteTagBtn);
  content.appendChild(controls);

  if (!items.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "No pages in this tag.";
    content.appendChild(empty);
    return;
  }

  const list = document.createElement("div");
  list.className = "list";
  items.forEach((it, idx) => {
    const row = document.createElement("div");
    row.className = "item";
    const icon = document.createElement("img");
    icon.src = it.favIconUrl || "icons/icon16.png";
    const info = document.createElement("div");
    info.className = "grow";
    const title = document.createElement("div");
    title.className = "title";
    const link = document.createElement("a");
    link.href = it.url;
    link.target = "_blank";
    link.textContent = it.title || it.url;
    title.appendChild(link);
    const meta = document.createElement("div");
    meta.className = "muted";
    meta.textContent = it.url + "  •  " + (fmtDate(it.savedAt) || "");
    info.append(title, meta);

    const restoreBtn = document.createElement("button");
    restoreBtn.textContent = "Restore";
    restoreBtn.onclick = () => chrome.runtime.sendMessage({ type: "restoreItem", item: it });

    const delBtn = document.createElement("button");
    delBtn.textContent = "Delete";
    delBtn.onclick = async () => {
      await chrome.runtime.sendMessage({ type: "deleteItem", tag, index: idx });
      render(tag);
    };

    row.append(icon, info, restoreBtn, delBtn);
    list.appendChild(row);
  });

  content.appendChild(list);
}

render(null);
