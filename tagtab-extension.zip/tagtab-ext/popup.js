const $ = sel => document.querySelector(sel);
const tagsEl = $("#tags");
const toast = $("#toast");

function showToast(msg) {
  toast.textContent = msg;
  toast.hidden = false;
  setTimeout(() => toast.hidden = true, 1600);
}

async function loadTags() {
  const res = await chrome.runtime.sendMessage({ type: "getTags" });
  tagsEl.innerHTML = "";
  if (res.ok && res.tags.length) {
    for (const t of res.tags) {
      const row = document.createElement("div");
      row.className = "tag";
      row.innerHTML = `<span>${t}</span><small>Save & close</small>`;
      row.addEventListener("click", async () => {
        const scope = $("#allWindows").checked ? "allWindows" : "currentWindow";
        const r = await chrome.runtime.sendMessage({ type: "saveAndClose", tag: t, scope });
        if (r.ok) showToast(`Saved ${r.saved} tabs to “${t}”`);
        window.close();
      });
      tagsEl.appendChild(row);
    }
  } else {
    const empty = document.createElement("div");
    empty.style.cssText = "padding:8px; color:#666; font-size:13px;";
    empty.textContent = "No tags yet.";
    tagsEl.appendChild(empty);
  }
}

$("#createNew").addEventListener("click", async () => {
  const name = prompt("New tag name:");
  if (!name) return;
  const scope = $("#allWindows").checked ? "allWindows" : "currentWindow";
  const r = await chrome.runtime.sendMessage({ type: "saveAndClose", tag: name.trim(), scope });
  if (r.ok) showToast(`Saved ${r.saved} tabs to “${name}”`);
  window.close();
});

$("#openManager").addEventListener("click", () => {
  // allow default link behavior
});

loadTags();
